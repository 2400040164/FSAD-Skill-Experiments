const webinars = [
  {
    id: 1,
    title: "Machine Learning Fundamentals",
    date: "Feb 26, 2026",
    speaker: "Dr. Sarah Johnson",
    duration: "2 Hours",
    description:
      "Learn supervised & unsupervised learning techniques and real-world ML applications.",
    videoUrl: "https://www.youtube.com/embed/GwIo3gDZCVQ"
  },
  {
    id: 2,
    title: "Digital Marketing 2026",
    date: "March 2, 2026",
    speaker: "Emma Wilson",
    duration: "2.5 Hours",
    description:
      "Master SEO, branding, analytics and social media marketing strategies.",
    videoUrl: "https://www.youtube.com/embed/nYdkjTtC2CE"
  },
  {
    id: 3,
    title: "Cloud Computing with AWS",
    date: "March 5, 2026",
    speaker: "John Miller",
    duration: "3 Hours",
    description:
      "Understand AWS services, deployment and scalable cloud systems.",
    videoUrl: "https://www.youtube.com/embed/ulprqHHWlng"
  }
];

export default webinars;