import React, { useState } from "react";
import "../App.css";

function Recordings() {

  const [activeVideo, setActiveVideo] = useState(null);

  const recordings = [
    {
      id: 1,
      title: "Machine Learning Fundamentals",
      speaker: "Dr. Sarah Johnson",
      duration: "2 Hours",
      description:
        "Complete introduction to supervised and unsupervised learning with real-world examples."
    },
    {
      id: 2,
      title: "Digital Marketing 2026",
      speaker: "Emma Wilson",
      duration: "2.5 Hours",
      description:
        "Advanced SEO, branding strategies and analytics insights for 2026."
    },
    {
      id: 3,
      title: "Cloud Computing with AWS",
      speaker: "John Miller",
      duration: "3 Hours",
      description:
        "Hands-on AWS deployment, cloud architecture and scalable systems."
    }
  ];

  return (
    <div>

      <div className="hero-section">
        <h1>Recorded Webinars</h1>
        <p>Access premium sessions anytime</p>
      </div>

      <div className="section">
        <h2 style={{ textAlign: "center", marginBottom: "40px" }}>
          Available Recordings
        </h2>

        <div style={{
          display: "flex",
          justifyContent: "center",
          gap: "40px",
          flexWrap: "wrap"
        }}>

          {recordings.map((rec) => (
            <div key={rec.id} className="webinar-card" style={{ width: "330px" }}>

              {/* Fake Video Preview Box */}
              <div style={{
                height: "180px",
                background: "linear-gradient(135deg, #4b000f, #000000)",
                borderRadius: "8px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "white",
                fontSize: "40px",
                marginBottom: "15px"
              }}>
                ▶
              </div>

              <h3>{rec.title}</h3>
              <p><strong>Speaker:</strong> {rec.speaker}</p>
              <p><strong>Duration:</strong> {rec.duration}</p>
              <p style={{ fontSize: "14px" }}>{rec.description}</p>

              <button
                className="primary-btn"
                style={{ width: "100%", marginTop: "10px" }}
                onClick={() => setActiveVideo(rec.title)}
              >
                Watch Recording
              </button>

            </div>
          ))}

        </div>

        {/* Modal Section */}
        {activeVideo && (
          <div style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100vh",
            background: "rgba(0,0,0,0.85)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 999
          }}>
            <div style={{
              background: "#111",
              padding: "40px",
              borderRadius: "10px",
              textAlign: "center",
              color: "white",
              width: "400px"
            }}>
              <h2>{activeVideo}</h2>
              <p style={{ marginTop: "15px" }}>
                This is a demo recording preview for project presentation.
              </p>

              <button
                className="primary-btn"
                style={{ marginTop: "20px" }}
                onClick={() => setActiveVideo(null)}
              >
                Close
              </button>
            </div>
          </div>
        )}

      </div>

      <div className="footer">
        © 2026 EduWebinar | Recorded Learning Hub
      </div>

    </div>
  );
}

export default Recordings;