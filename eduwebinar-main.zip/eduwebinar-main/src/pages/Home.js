import React from "react";
import { useNavigate } from "react-router-dom";
import webinars from "../data/webinars";
import "../App.css";

function Home() {

  const navigate = useNavigate();

  return (
    <div>

      <div className="hero-section">
        <h1>Learn from Industry Experts</h1>
        <p>Premium Webinars & Professional Workshops</p>
      </div>

      <div className="section">
        <h2 style={{ textAlign: "center", marginBottom: "40px" }}>
          Upcoming Webinars
        </h2>

        <div style={{
          display: "flex",
          justifyContent: "center",
          gap: "30px",
          flexWrap: "wrap"
        }}>

          {webinars.map((webinar) => (
            <div
              key={webinar.id}
              className="webinar-card"
              style={{ cursor: "pointer" }}
              onClick={() => navigate("/register", { state: webinar })}
            >
              <h3>{webinar.title}</h3>
              <p>📅 {webinar.date}</p>
              <p>👨‍🏫 {webinar.speaker}</p>
              <button className="primary-btn" style={{ width: "100%" }}>
                Register Now
              </button>
            </div>
          ))}

        </div>
      </div>

      <div className="footer">
        © 2026 EduWebinar | Premium Learning Platform
      </div>

    </div>
  );
}

export default Home;