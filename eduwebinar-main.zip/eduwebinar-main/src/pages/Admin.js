import React, { useState, useEffect } from "react";
import "../App.css";

function Admin() {

  const [registrations, setRegistrations] = useState([]);

  // Load from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("registrations");
    if (saved) {
      setRegistrations(JSON.parse(saved));
    }
  }, []);

  // Delete function
  const handleDelete = (indexToDelete) => {
    const updatedList = registrations.filter(
      (_, index) => index !== indexToDelete
    );

    setRegistrations(updatedList);
    localStorage.setItem("registrations", JSON.stringify(updatedList));
  };

  return (
    <div>

      <div className="hero-section">
        <h1>Admin Dashboard</h1>
        <p>Manage Registered Users</p>
      </div>

      <div className="section">

        {registrations.length === 0 ? (
          <h3 style={{ textAlign: "center" }}>
            No registrations available.
          </h3>
        ) : (
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              flexWrap: "wrap",
              gap: "25px"
            }}
          >
            {registrations.map((user, index) => (
              <div
                key={index}
                className="webinar-card"
                style={{
                  width: "320px",
                  background: "#111",
                  color: "white",
                  position: "relative"
                }}
              >
                <h4>{user.name}</h4>
                <p><strong>Email:</strong> {user.email}</p>
                <p><strong>Phone:</strong> {user.phone}</p>
                <p><strong>Webinar:</strong> {user.webinarTitle}</p>

                <button
                  style={{
                    marginTop: "15px",
                    width: "100%",
                    padding: "10px",
                    background: "#7b001c",
                    color: "white",
                    border: "none",
                    borderRadius: "6px",
                    cursor: "pointer"
                  }}
                  onClick={() => handleDelete(index)}
                >
                  Delete Registration
                </button>

              </div>
            ))}
          </div>
        )}

      </div>

      <div className="footer">
        © 2026 EduWebinar | Admin Panel
      </div>

    </div>
  );
}

export default Admin;