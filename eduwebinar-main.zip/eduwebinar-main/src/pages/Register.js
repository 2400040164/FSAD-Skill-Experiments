import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import "../App.css";

function Register() {

  const location = useLocation();
  const webinar = location.state;

  const [registrations, setRegistrations] = useState(() => {
    const saved = localStorage.getItem("registrations");
    return saved ? JSON.parse(saved) : [];
  });

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: ""
  });

  useEffect(() => {
    localStorage.setItem("registrations", JSON.stringify(registrations));
  }, [registrations]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const newRegistration = {
      ...formData,
      webinarTitle: webinar ? webinar.title : "General Registration"
    };

    setRegistrations([...registrations, newRegistration]);

    setFormData({
      name: "",
      email: "",
      phone: ""
    });

    alert("Registration Successful!");
  };

  return (
    <div>

      {webinar && (
        <div className="hero-section">
          <h1>{webinar.title}</h1>
          <p>📅 {webinar.date}</p>
          <p>👨‍🏫 {webinar.speaker}</p>
          <p>⏳ {webinar.duration}</p>
        </div>
      )}

      <div className="section" style={{ display: "flex", justifyContent: "center" }}>
        <div className="webinar-card" style={{ width: "400px" }}>

          <h3 style={{ marginBottom: "20px" }}>Register Now</h3>

          <form onSubmit={handleSubmit}>
            <input name="name" value={formData.name} onChange={handleChange} style={inputStyle} placeholder="Full Name" required />
            <input name="email" value={formData.email} onChange={handleChange} style={inputStyle} placeholder="Email" required />
            <input name="phone" value={formData.phone} onChange={handleChange} style={inputStyle} placeholder="Phone" required />
            <button className="primary-btn" style={{ width: "100%" }}>
              Submit Registration
            </button>
          </form>

        </div>
      </div>

      <div className="footer">
        © 2026 EduWebinar
      </div>

    </div>
  );
}

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginBottom: "15px",
  borderRadius: "8px",
  border: "none"
};

export default Register;